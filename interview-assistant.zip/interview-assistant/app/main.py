"""
Entry point dell'applicazione.

Uso:
    python -m app.main          (sviluppo)
    InterviewAssistant.exe      (dopo il build con PyInstaller)
"""
import sys

from PySide6.QtWidgets import QApplication

from app.ui.main_window import MainWindow


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("InterviewAssistant")
    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
